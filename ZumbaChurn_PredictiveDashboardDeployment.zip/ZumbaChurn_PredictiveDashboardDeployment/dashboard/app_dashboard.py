# ============================================================
# DASHBOARD FINAL DE CHURN BASADO SOLO EN PREDICCIONES
# ============================================================

import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px

from pathlib import Path

# ============================================================
# 1. CARGA DEL ARCHIVO DE PREDICCIONES
# ============================================================

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / 'data' / 'predictions_ChurnPredictedData.csv'

df = pd.read_csv(DATA_PATH)

# Eliminar primera columna vacía si existe
if df.columns[0].startswith("Unnamed") or df.columns[0] == "":
    df = df.drop(df.columns[0], axis=1)

# ============================================================
# 2. CREAR SEGMENTO DE RIESGO
# ============================================================

df["RISK_SEGMENT"] = pd.cut(
    df["PREDICTED_PROBABILITY"],
    bins=[0, 0.33, 0.66, 1.0],
    labels=["Bajo Riesgo (0-33%)", "Riesgo Medio (33-66%)", "Alto Riesgo (66-100%)"],
    include_lowest=True
)

risk_counts = df["RISK_SEGMENT"].value_counts()
TOTAL_USERS = len(df)

# ============================================================
# 3. MÉTRICAS DEL MODELO 
# ============================================================

MODEL_METRICS = {
    "auc": 0.659,
    "accuracy": 0.614,
    "precision": 0.584,
    "recall": 0.528,
    "f1": 0.554
}

# ============================================================
# 4. IMPORTANCIA DE VARIABLES (VARIANZA)
# ============================================================

feature_columns = [
    col for col in df.columns
    if col not in ["PREDICTED_PROBABILITY", "PREDICTED_CLASS", "RISK_SEGMENT", "COUNTRY"]
]

numeric_df = df[feature_columns].select_dtypes(include=[np.number])
importance = numeric_df.var().sort_values(ascending=False).head(10)
importance_df = pd.DataFrame({"Feature": importance.index, "Importance": importance.values})

# ============================================================
# 5. ESTILOS DE TARJETAS
# ============================================================

CARD_STYLE = {
    'borderRadius':'12px',
    'padding':'20px',
    'backgroundColor':'white',
    'boxShadow':'0 3px 10px rgba(0,0,0,0.12)',
    'flex':'1',
    'minWidth':'250px'
}

def kpi_card(title, value, description, color="#00c7e5"):
    return html.Div(style=CARD_STYLE, children=[
        html.P(title, style={'color':'#6b7280','fontSize':'14px','marginBottom':'4px'}),
        html.H3(
            f"{value:,}".replace(",", "."),
            style={'color':color,'fontWeight':'700','fontSize':'32px','margin':'0'}
        ),
        html.P(description, style={'color':'#9ca3af','fontSize':'12px','marginTop':'6px'})
    ])

# ============================================================
# 6. GRÁFICAS
# ============================================================

def plot_feature_importance(df_importance):
    fig = go.Figure(go.Bar(
        x=df_importance["Importance"][::-1],
        y=df_importance["Feature"][::-1],
        orientation="h",
        marker_color="#00c7e5"
    ))
    fig.update_layout(
        title="Top 10 Variables con Mayor Influencia",
        height=380,
        margin=dict(l=160, r=20, t=40, b=20),
        plot_bgcolor="white",
        paper_bgcolor="white"
    )
    return fig


def plot_risk_distribution():
    fig = go.Figure(go.Bar(
        x=risk_counts.index,
        y=risk_counts.values,
        marker_color=["#00c7e5","#f59e0b","#ef4444"],
        text=risk_counts.values,
        textposition="outside"
    ))
    fig.update_layout(
        title="Distribución de Probabilidad de Churn",
        yaxis_title="Usuarios",
        height=380,
        plot_bgcolor="white",
        paper_bgcolor="white"
    )
    return fig


def plot_risk_by_country(country):
    sub = df[df["COUNTRY"].astype(str) == str(country)]
    if sub.empty:
        return go.Figure().update_layout(title="No hay datos para este país")

    counts = sub["RISK_SEGMENT"].value_counts().reindex(
        ["Bajo Riesgo (0-33%)","Riesgo Medio (33-66%)","Alto Riesgo (66-100%)"]
    ).fillna(0)

    fig = go.Figure(go.Bar(
        x=counts.index,
        y=counts.values,
        marker_color=["#00c7e5","#f59e0b","#ef4444"],
        text=counts.values,
        textposition="outside"
    ))

    fig.update_layout(
        title="Distribución de Riesgo por País",
        height=380,
        plot_bgcolor="white",
        paper_bgcolor="white",
        yaxis=dict(title="Usuarios", gridcolor="#e5e7eb")
    )

    return fig


def plot_country_heatmap(segment):

    ranges = {
        "Bajo Riesgo (0-33%)": (0,0.33),
        "Riesgo Medio (33-66%)": (0.33,0.66),
        "Alto Riesgo (66-100%)": (0.66,1.0)
    }

    low, high = ranges[segment]

    df["IN_SEGMENT"] = df["PREDICTED_PROBABILITY"].between(low, high)

    summary = df.groupby("COUNTRY")["IN_SEGMENT"].mean().reset_index()
    summary["Pct"] = summary["IN_SEGMENT"] * 100

    avg = summary["Pct"].mean()
    color_max = max(5, avg * 2)

    fig = px.choropleth(
        summary,
        locations="COUNTRY",
        locationmode="country names",
        color="Pct",
        color_continuous_scale="Reds",
        range_color=[0, color_max],
        title=f"Mapa de Calor – {segment}"
    )

    fig.update_layout(
        height=400,
        width=480,
        margin=dict(l=20,r=20,t=40,b=20),
        geo=dict(
            bgcolor="rgba(0,0,0,0)",
            showframe=False,
            showcoastlines=True,
            coastlinecolor="#ccc",
            projection_scale=1
        )
    )

    fig.update_coloraxes(colorbar=dict(
        title="% usuarios",
        thickness=10,
        len=0.6
    ))

    return fig


# ============================================================
# 7. CREAR APP
# ============================================================

external_css = [
    "https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
]

app = dash.Dash(__name__, external_stylesheets=external_css)
server = app.server

app.title = "Dashboard Churn – Predicciones"

# ============================================================
# 8. LAYOUT 
# ============================================================

country_list = (
    df["COUNTRY"].fillna("Unknown").astype(str).unique()
)
default_country = (
    "United States of America" if "United States of America" in country_list
    else sorted(country_list)[0]
)

app.layout = html.Div(style={
    'padding':'20px',
    'maxWidth':'1400px',
    'margin':'0 auto',
    'backgroundColor':'#f7f9fc',
    'fontFamily':'Inter, sans-serif'
}, children=[

    html.H2("Sistema de Prevención del Churn",
            style={'fontWeight':'800','fontSize':'26px'}),

    html.P(
        f"Resultados basados en el archivo de predicciones pre-generadas. "
        f"Total de usuarios evaluados: {TOTAL_USERS:,}.",
        style={'color':'#6b7280','marginBottom':'25px'}
    ),

    # ------------------------------------------------------------
    # 1. TOTAL USUARIOS
    # ------------------------------------------------------------
    html.H3("1. Total de Usuarios y Segmentación de Riesgo"),

    html.Div(style={'display':'flex','gap':'20px','marginBottom':'30px'}, children=[
        kpi_card("Total de Usuarios Evaluados", TOTAL_USERS,
                 "Tamaño total del archivo de predicciones.")
    ]),

    html.H3("Desglose de Clientes por Segmento de Riesgo"),

    html.Div(style={
        'display':'flex',
        'gap':'20px',
        'flexWrap':'wrap',
        'marginBottom':'40px'
    }, children=[
        kpi_card("Bajo Riesgo (0-33%)", risk_counts.get("Bajo Riesgo (0-33%)",0),
                 "Clientes estables con baja probabilidad de Churn.", "#00c7e5"),
        kpi_card("Riesgo Medio (33-66%)", risk_counts.get("Riesgo Medio (33-66%)",0),
                 "Clientes a monitorear; potencial para ofertas.", "#f59e0b"),
        kpi_card("Alto Riesgo (66-100%)", risk_counts.get("Alto Riesgo (66-100%)",0),
                 "Clientes en riesgo inminente de rotación.", "#ef4444")
    ]),

    # ------------------------------------------------------------
    # 2. MÉTRICAS FIJAS
    # ------------------------------------------------------------
    html.H3("2. Calidad y Estabilidad del Modelo Optimizado"),

    html.Div(style={
        'display':'flex',
        'gap':'20px',
        'flexWrap':'wrap',
        'justifyContent':'space-between',
        'marginBottom':'40px'
    }, children=[
        kpi_card("ROC AUC", MODEL_METRICS["auc"], "Capacidad predictiva.", "#00c7e5"),
        kpi_card("Accuracy", MODEL_METRICS["accuracy"], "Tasa de aciertos.", "#00c7e5"),
        kpi_card("Precision", MODEL_METRICS["precision"], "Exactitud de positivos.", "#00c7e5"),
        kpi_card("Recall", MODEL_METRICS["recall"], "Captura de churn.", "#00c7e5"),
        kpi_card("F1 Score", MODEL_METRICS["f1"], "Balance entre Precision y Recall.", "#00c7e5")
    ]),

    # ------------------------------------------------------------
    # 3. INSIGHTS
    # ------------------------------------------------------------
    html.H3("3. Insights y Distribución de Probabilidad"),

    html.Div(style={'display':'flex','gap':'20px','marginBottom':'40px'}, children=[
        html.Div(style={'flex':'1'}, children=[dcc.Graph(figure=plot_feature_importance(importance_df))]),
        html.Div(style={'flex':'1'}, children=[dcc.Graph(figure=plot_risk_distribution())])
    ]),

    # ------------------------------------------------------------
    # 4. PAÍSES
    # ------------------------------------------------------------
    html.H3("4. Análisis por País"),

    html.Label("Seleccione un país:", style={'fontWeight':'600'}),
    dcc.Dropdown(
        id="country_selector",
        options=[{"label":c, "value":c} for c in sorted(country_list)],
        value=default_country,
        style={'width':'400px','marginBottom':'20px'}
    ),

    html.Div(style={'display':'flex','gap':'20px','marginBottom':'40px',
                    'flexWrap':'wrap'}, children=[

        html.Div(style={'flex':'1'}, children=[dcc.Graph(id="risk_by_country_chart")]),

        html.Div(style={'flex':'1'}, children=[
            html.Label("Seleccione riesgo:", style={'fontWeight':'600'}),
            dcc.Dropdown(
                id="risk_selector",
                options=[
                    {"label":"Bajo Riesgo (0-33%)","value":"Bajo Riesgo (0-33%)"},
                    {"label":"Riesgo Medio (33-66%)","value":"Riesgo Medio (33-66%)"},
                    {"label":"Alto Riesgo (66-100%)","value":"Alto Riesgo (66-100%)"}
                ],
                value="Alto Riesgo (66-100%)",
                style={'width':'300px','marginBottom':'10px'}
            ),
            dcc.Graph(id="heatmap_chart")
        ])
    ])

])

# ============================================================
# 9. CALLBACKS
# ============================================================

@app.callback(
    Output("risk_by_country_chart", "figure"),
    Input("country_selector", "value")
)
def update_country_chart(country):
    return plot_risk_by_country(country)


@app.callback(
    Output("heatmap_chart", "figure"),
    Input("risk_selector", "value")
)
def update_heatmap(segment):
    return plot_country_heatmap(segment)

# ============================================================
# EJECUTAR APP
# ============================================================
if __name__ == "__main__":
    print("Dashboard disponible en http://localhost:8050")
    app.run(host="0.0.0.0", port=8050, debug=False)